# Deploy pe Netlify sau GitHub Pages
1. Descarcă arhiva ZIP.
2. Pentru Netlify: Drag & Drop în dashboard.
3. Pentru GitHub Pages: urcă fișierele într-un repository și activează Pages.
